package YahtzeeProject;
public class ChanceScore extends YahtzeeScore {
	
	public ChanceScore(String s) {
		super(s);
	}
	
	public int calculateScore(int[] values) {	
		int total = 0;
		for (int i = 0; i < values.length; i++) {
			total += values[i];
		}
		return total;
	} 
}
