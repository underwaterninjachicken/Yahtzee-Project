package YahtzeeProject;
import java.util.Arrays;

public class FullHouseScore extends YahtzeeScore {

	public FullHouseScore(String s) {
		super(s);
	}
	
	public int calculateScore(int[] values) {
		boolean isPair = false;
		boolean isTrio = false;
		Arrays.sort(values);
		for (int i = 0; i < values.length; i++) {
			if (i == 0) {
				if (values[i] == values[i + 1] && values[i] == values [i + 2]) isTrio = true;
			} else if (i == values.length - 1) {
				if (values[i] == values[i - 1] && values[i] == values [i - 2]) isTrio = true;
			} else {
				if (values[i] == values[i - 1] && values[i] == values[i + 1]) isTrio = true;
			}
			if (i == 0) {
				if (values[i] == values[i + 1]) isPair = true;
			} else if (i == values.length - 1) {
				if (values[i] == values[i - 1]) isPair = true;
			} else {
				if (values[i] == values[i - 1] || values[i] == values[i + 1]) isPair = true;
			}
		}
		if (isPair && isTrio) return 25;
		return 0;
	}
}