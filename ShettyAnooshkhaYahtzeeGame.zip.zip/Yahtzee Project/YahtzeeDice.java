/**
 * YahtzeeDice
 */
package YahtzeeProject;
public class YahtzeeDice {

    // instance variables
    Die[] diceQuintet = new Die[5];

    // constructors
    public YahtzeeDice() 
    {
        for (int i = 0; i < 5; i++) {
            diceQuintet[i] = new Die();
        }
    }

    public YahtzeeDice(int numSides) {
        for (int i = 0; i < 5; i++) {
            diceQuintet[i] = new Die(numSides);
        }
    }

    // methods
    // public int roll() {
    //     int sum = 0;
    //     for (int i = 0; i < 5; i++) {
    //         sum += diceQuintet[i].roll();
    //     }
    //     return sum;
    // }

    public int roll(String saveNum) {
        int sum = 0;
        boolean thisNum;
        for (int i = 0; i < 5; i++) {
            if (saveNum.length() == 0) {
                sum += diceQuintet[i].roll();
                continue;
            }
            thisNum = false;
            for (int k = 0; k < saveNum.length(); k++) {
                if (Integer.parseInt(saveNum.substring(k, k + 1)) == i + 1) thisNum = true;
            }
            if (!thisNum) sum += diceQuintet[i].roll();
            else sum += diceQuintet[i].getCurrentValue();
        }
        return sum;
    }

    public Die[] getDice() {
		return diceQuintet;
    }
    public int[] getDiceValues() {
        return new int[] {diceQuintet[0].getCurrentValue(), diceQuintet[1].getCurrentValue(),
                            diceQuintet[2].getCurrentValue(), diceQuintet[3].getCurrentValue(),
                            diceQuintet[4].getCurrentValue()};
    }

    public String toString() {
    	System.out.println("Rolling...");
        String str = "The 5 dice read: ";
        for (int i = 0; i < diceQuintet.length; i++) {
            if (i < diceQuintet.length - 1) {
                str += diceQuintet[i].getCurrentValue() + ", ";
            } else {
                str += diceQuintet[i].getCurrentValue() + ".";
            }
        }
        return str;
    }
}