package YahtzeeProject;
import java.util.Arrays;

public class SmallStraightScore extends YahtzeeScore {
	
	public SmallStraightScore(String s) {
		super(s);
	}
	
	public int calculateScore(int[] values) {
		Arrays.sort(values);
		for (int i = 0; i < 3; i++) {
			if (values[i] == values[i + 1] - 1 && values[i + 1] == values[i + 2] - 1 && values[i + 2] == values[i + 3] - 1) {
				return 30;
			}
		}
		return 0;
	} 
}