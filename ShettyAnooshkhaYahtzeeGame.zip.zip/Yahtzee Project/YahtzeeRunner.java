/**
 * YahtzeeRunner
 */
package YahtzeeProject;
public class YahtzeeRunner {

    public static void main(String[] args) {
        
        YahtzeeGame newGame = new YahtzeeGame();
        Scoreboard Board= new Scoreboard();
        String saveNum;
        boolean playGame;
        int counter;
        int move;
        
        System.out.println("***STARTING ROUND***");
        System.out.println("You have a max of 3 turns per round.");
        
        for (int i = 0; i < 13; i++) {
            saveNum = "";
            playGame = true;
            counter = 2;
            newGame.gameDice.roll(saveNum);
            System.out.println(newGame.playRound());
            
            while (playGame && counter != 0) 
            {
                for (int j = 1; j < 6; j++)
                {
                    System.out.print("Hold die " + j + "? ");
                    if (TextIO.getlnChar() == 'y') {
                        saveNum += j;
                    }
                }
                System.out.print("Would you like to roll again (" + counter + " roll(s) left)? ");
                if (TextIO.getlnChar() == 'y')
                {
                    newGame.gameDice.roll(saveNum);
                    System.out.println(newGame.playRound());
                    counter--;
                } 
                else 
                	playGame = false;
            }
            
            String str = "Score numbers:\n";
            for (int x = 0; x < 13; x++) {
            	int num = x + 1;
                str += String.format("%-25s", Board.getScoreForAType(x) + " (is " + num + ")" );
                if (x > 0 && x % 4 == 0) 
                	str += "\n";
            }
            System.out.println(str);
            System.out.println("Choose a score to take (1 - 13): ");
            move = TextIO.getlnInt();
            while (Board.getScoreMoved(move)) 
            {
                System.out.print("Input a move you haven't done already (1 - 13): ");
                move = TextIO.getlnInt();
                if (!Board.getScoreMoved(move)) break;
            }
            
            Board.userChoice(move, newGame.gameDice);
            System.out.println(Board);
            
            //print score card
            if (Board.isGameOver()) 
            {
             System.out.println("GAME OVER!");
             System.out.println("****FINAL SCORE: " + Board.toString());
             break;
            }
        }

    }
    // public static String askToHold() {
    //     String saveNum = "";
    //     for (int i = 1; i < 6; i++) {
    //         System.out.print("Hold die " + i + "? ");
    //         if (TextIO.getlnChar() == 'y') {
    //             saveNum += i;
    //         }
    //     }
    //     return saveNum;
    // }
}