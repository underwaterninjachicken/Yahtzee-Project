package YahtzeeProject;
public class YahtzeeScore {
	
	private String scoreType = "";
	private int scoreValue = 0;
	private boolean scorePlayed = false;

	public YahtzeeScore(String s) 
	{
		this.scoreType = s;
	}
	
	
	public int calculateScore(int[] values) {
		if (values[0] == values[1] && values[1] == values[2] && values[2] == values[3] && values[3] == values[4] && values[4] == values[5]) {
			return 50;
		}
		return 0;
	}
	
	public String getScoreType() {
		return scoreType;
	}
	public void setScoreType(String newType) {
		scoreType = newType;
	}
	public int getScoreValue() {
		return scoreValue;
	}
	public void setScoreValue(int newScoreValue) {
		scoreValue = newScoreValue;
	}
	public boolean getScorePlayed() {
		return scorePlayed;
	}
	public void setScorePlayed() {
		if (!scorePlayed) scorePlayed = true;
	}
}
