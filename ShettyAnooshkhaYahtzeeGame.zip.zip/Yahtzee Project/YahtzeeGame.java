/**
 * YahtzeeGame
 */
package YahtzeeProject;
public class YahtzeeGame {

    YahtzeeDice gameDice = new YahtzeeDice();

    public String playRound() 
    {
        return gameDice.toString();
    }
}