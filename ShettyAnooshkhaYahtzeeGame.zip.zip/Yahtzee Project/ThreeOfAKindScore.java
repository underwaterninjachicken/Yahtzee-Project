package YahtzeeProject;
import java.util.Arrays;

public class ThreeOfAKindScore extends YahtzeeScore {
	public ThreeOfAKindScore(String s) {
		super(s);
	}
	
	public int calculateScore(int[] values) {
		int total = 0;
		boolean isThreeOfAKind = false;
		Arrays.sort(values);
		for (int i = 0; i < values.length; i++) {
			if (i == 0) {
				if (values[i] == values[i + 1] && values[i] == values [i + 2]) isThreeOfAKind = true;
			} else if (i == values.length - 1) {
				if (values[i] == values[i - 1] && values[i] == values [i - 2]) isThreeOfAKind = true;
			} else {
				if (values[i] == values[i - 1] && values[i] == values[i + 1]) isThreeOfAKind = true;
			}
			total += values[i];
		}
		if (isThreeOfAKind) return total;
		return 0;
	} 
}