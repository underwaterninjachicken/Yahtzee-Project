/**
 * Scoreboard
 */
package YahtzeeProject;
public class Scoreboard {

    private YahtzeeScore[] scores = new YahtzeeScore[13];

    public Scoreboard() {
        scores[0] = new OnesScore("Ones");
        scores[1] = new TwosScore("Twos");
        scores[2] = new ThreesScore("Threes");
        scores[3] = new FoursScore("Fours");
        scores[4] = new FivesScore("Fives");
        scores[5] = new SixesScore("Sixes");
        scores[6] = new ThreeOfAKindScore("Three of a kind");
        scores[7] = new FourOfAKindScore("Four of a kind");
        scores[8] = new FullHouseScore("Full House");
        scores[9] = new SmallStraightScore("Small Straight");
        scores[10] = new LargeStraightScore("Large Straight");
        scores[11] = new ChanceScore("Chance");
        scores[12] = new YahtzeeScore("Yahtzee");
    }
    public void userChoice(int choice, YahtzeeDice values) {
        int i = choice - 1;
        scores[i].setScorePlayed();
        scores[i].setScoreValue(scores[i].calculateScore(values.getDiceValues()));
    }
    
    public String getScoreForAType(int x)  
    {
    		 return scores[x].getScoreType();
    }
    public boolean getScoreMoved(int move) {
        return scores[move - 1].getScorePlayed();
    }
    public boolean isGameOver() {
    	for (int i = 0; i < 13; i++) {
            if (scores[i].getScorePlayed() == false)
            	return false;
        }
        return true;
    }
    public int getTotalScore() {
        int totalScore = 0;
        for (int i = 0; i < 13; i++) {
            if (scores[i].getScorePlayed()) 
            	totalScore += scores[i].getScoreValue();
        }
        return totalScore;
    }
    public String toString() {
        String str = "Current Scores:\n";
        for (int i = 0; i < 13; i++) {
            str += String.format("%-25s", scores[i].getScoreType() + ": " + scores[i].getScoreValue());
            if (i > 0 && i % 4 == 0) str += "\n";
        }
        str += "Total: " + getTotalScore();
        return str;
    }
}