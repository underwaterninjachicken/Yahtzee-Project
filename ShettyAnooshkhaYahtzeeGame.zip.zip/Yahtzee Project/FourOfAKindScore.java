package YahtzeeProject;
import java.util.Arrays;

public class FourOfAKindScore extends YahtzeeScore {

	public FourOfAKindScore(String s) {
		super(s);
	}

	public int calculateScore(int[] values) {
		int total = 0;
		boolean isFourOfAKind = false;
		Arrays.sort(values);
		for (int i = 0; i < values.length; i++) {
			if (i == 0) {
				if (values[i] == values[i + 1] && values[i] == values [i + 2] && values[i] == values[i + 3]) isFourOfAKind = true;
			} else if (i == values.length - 1) {
				if (values[i] == values[i - 1] && values[i] == values [i - 2] && values[i] == values[i - 3]) isFourOfAKind = true;
			} else {
				if (values[1] == values[2] && values[2] == values[3] && values[3] == values[4]) isFourOfAKind = true;
			}
			total += values[i];
		}
		if (isFourOfAKind) return total;
		return 0;
	} 
}