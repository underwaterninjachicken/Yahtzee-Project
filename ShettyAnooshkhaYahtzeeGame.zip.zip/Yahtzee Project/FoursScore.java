package YahtzeeProject;
public class FoursScore extends YahtzeeScore {
	
	public FoursScore(String s) {
		super(s);
	}
	
	public int calculateScore(int[] values) {	
		int sumOfFours = 0;
		for (int i = 0; i < values.length; i++) {
			if (values[i] == 4) sumOfFours += 4;
		}
		return sumOfFours;
	}  
}
