package YahtzeeProject;
public class OnesScore extends YahtzeeScore {
	
	public OnesScore(String s) {
		super(s);
	}
	
	public int calculateScore(int[] values) {	
		int sumOfOnes = 0;
		for (int i = 0; i < values.length; i++) {
			if (values[i] == 1) sumOfOnes++;
		}
		return sumOfOnes;
	} 
}
