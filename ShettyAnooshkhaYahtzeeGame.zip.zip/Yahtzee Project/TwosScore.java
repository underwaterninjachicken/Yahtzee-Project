package YahtzeeProject;
public class TwosScore extends YahtzeeScore {
	
	public TwosScore(String s) {
		super(s);
	}
	

	public int calculateScore(int[] values) {	
		int sumOfTwos = 0;
		for (int i = 0; i < values.length; i++) {
			if (values[i] == 2) sumOfTwos += 2;
		}
		return sumOfTwos;
	} 
}